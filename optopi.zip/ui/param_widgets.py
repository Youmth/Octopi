from dataclasses import dataclass

from PySide6.QtCore import QLocale, Signal
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import QFormLayout, QLineEdit, QWidget


@dataclass(frozen=True)
class ParamSpec:
    """Description of one numeric parameter."""
    label: str
    default: float
    unit: str = ""
    tooltip: str = ""
    positive: bool = False  # reject zero and negative values


class ParametersPanel(QWidget):
    """A form of numeric entries built from a {key: ParamSpec} table.

    * Values live in the dict you pass in (`values`): the panel writes the
      key there each time the user commits an entry (Enter or focus lost).
      Missing keys are filled with the spec default.
    * `show_only(keys)` shows just those rows. Hidden rows keep their value,
      so a parameter shared by several algorithms is typed only once.
    * Entries accept scientific notation (3e-10) and always use '.' as the
      decimal separator, whatever the system locale is.
    """

    changed = Signal(str, float)  # key, new value

    def __init__(self, specs: dict[str, ParamSpec], values: dict):
        super().__init__()
        self.specs = specs
        self.values = values
        self._fields: dict[str, QLineEdit] = {}
        self._form = QFormLayout(self)

        for key, spec in specs.items():
            if values.get(key) is None:
                values[key] = spec.default

            validator = QDoubleValidator(self)
            validator.setNotation(QDoubleValidator.ScientificNotation)
            validator.setLocale(QLocale.c())

            edit = QLineEdit(self._fmt(values[key]))
            edit.setValidator(validator)
            edit.setToolTip(spec.tooltip)
            edit.editingFinished.connect(lambda k=key: self._commit(k))
            self._fields[key] = edit

            label = f"{spec.label} ({spec.unit})" if spec.unit else spec.label
            self._form.addRow(label, edit)

    @staticmethod
    def _fmt(value: float) -> str:
        return f"{value:.10g}"

    def _commit(self, key: str):
        edit, spec = self._fields[key], self.specs[key]
        value, ok = QLocale.c().toDouble(edit.text())
        if not ok or (spec.positive and value <= 0):
            edit.setText(self._fmt(self.values[key]))  # revert to last good value
            return
        edit.setText(self._fmt(value))
        if value != self.values[key]:
            self.values[key] = value
            self.changed.emit(key, value)

    def show_only(self, keys):
        keys = set(keys)
        for key, edit in self._fields.items():
            self._form.setRowVisible(edit, key in keys)