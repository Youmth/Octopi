from PySide6.QtWidgets import QFileDialog, QLabel, QRadioButton, QButtonGroup, QWidget, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox, QCheckBox, QDockWidget
from PySide6.QtCore import Qt

from core.io import load_grayscale
from .base import Page
from ui.param_widgets import ParametersPanel, ParamSpec
from core.reconstruction import reconstruct

import numpy as np


class DLHMStatic(Page):
    title = "Static reconstruction"

    ALGORITHMS = {
        "AS": ("Angular spectrum", ("r", "wavelength", "dxy", "scale_factor")),
        "KR": ("Kreuzer", ("Z", "L", "wavelength", "dxy")),
    }

    DEFAULT_ALGORITHM = "AS"

    MODES = {
        'squared' : ('Intensity', True),
        'phase': ('Phase', False),
        'amplitude': ('Amplitude', False)
    }
    DEFAULT_MODE = "phase"

    PARAMS = {
        "r": ParamSpec("Distance r", 0.1, tooltip="Propagation distance"),
        "Z": ParamSpec("Distance Z", 0.1, tooltip="Reconstruction distance"),
        "L": ParamSpec("Source distance L", 1.0, tooltip="Point source to detector distance"),
        "wavelength": ParamSpec("Wavelength", 3e-10, positive=True),
        "dxy": ParamSpec("Pixel pitch dxy", 0.01, positive=True),
        "scale_factor": ParamSpec("Scale factor", 2, positive=True),
    }


    def __init__(self):
        super().__init__()
        self.hologram = None
        self.reconstruction = None
        self.input_dict = {
            'image':None,
            'squared':None,
            'phase':None,
            'algorithm': None,
            'r': None,
            'wavelength': None,
            'dxy': None,
            'scale_factor': None,
        }

        self.open_button = QPushButton("Open hologram...")
        self.open_button.clicked.connect(self.open_hologram)

        self.reconstruct_button = QPushButton("Reconstruct from current parameters.")
        self.reconstruct_button.clicked.connect(self.reconstruct_hologram)

        # Checkbox panel: lives in a dock, not in this page's layout.
        # Each entry: input_dict key -> (label, default state)
        self.mode_boxes: dict[str, QCheckBox] = {}

        mode_widget = QWidget()
        mode_layout = QVBoxLayout()
        self.mode_group = QButtonGroup(self)
        self.mode_buttons:dict[str,QRadioButton] = {}
        for key, (label, default) in self.MODES.items():
            button = QRadioButton(label)
            self.input_dict[key] = default
            button.toggled.connect(lambda checked, k=key:self.input_dict.__setitem__(k, checked))
            self.mode_group.addButton(button)
            self.mode_buttons[key] = button
            mode_layout.addWidget(button)
        mode_layout.addStretch()

        mode_widget.setLayout(mode_layout)

        self.mode_dock = self.add_panel("Mode", mode_widget)

        self.algorithm_box = QComboBox()
        for key, (name, _) in self.ALGORITHMS.items():
            self.algorithm_box.addItem(name, key)
        algorithm_widget = QWidget()
        algorithm_layout = QVBoxLayout(algorithm_widget)
        algorithm_layout.addWidget(self.algorithm_box)
        algorithm_layout.addStretch()
        self.algorithm_dock = self.add_panel("Algorithm", algorithm_widget)

        self.params_panel = ParametersPanel(self.PARAMS, self.input_dict)
        self.params_dock = self.add_panel("Parameters", self.params_panel)

        self.algorithm_box.currentIndexChanged.connect(self._on_algorithm_changed)
        self.mode_buttons[self.DEFAULT_MODE].setChecked(True)
        self._on_algorithm_changed()

        self.info = QLabel("No hologram loaded")
        self.info.setWordWrap(True)

        self.info_recon = QLabel("No reconstruction has been performed")
        self.info_recon.setWordWrap(True)

        layout = QVBoxLayout(self)
        layout.addWidget(self.open_button)
        layout.addWidget(self.info)
        layout.addWidget(self.reconstruct_button)
        layout.addWidget(self.info_recon)

        layout.addStretch()
    def _on_algorithm_changed(self, *args):
        key = self.algorithm_box.currentData()
        self.input_dict['algorithm'] = key
        self.params_panel.show_only(self.ALGORITHMS[key][1])
    def _set_mode(self,mode:str):
        self.input_dict['squared'] = mode == "intensity"
        self.input_dict['phase'] = mode=="phase"
    def open_hologram(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open hologram",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff)",
        )
        if not path:
            return
        self.hologram = load_grayscale(path)
        h, w = self.hologram.shape
        self.info.setText(f"{path}\n{w} x {h} px")
        self.image_ready.emit("hologram", self.hologram)


    def reconstruct_hologram(self):
        if self.hologram is None:
            self.info_recon.setText('Open a hologram first')
            return

        recon_dict = dict(self.input_dict)
        recon_dict['image'] = self.hologram

        self.reconstruction, fps = reconstruct(recon_dict)
        self.reconstruction_ready.emit('reconstruction', self.reconstruction)

        name = self.ALGORITHMS[recon_dict['algorithm']]
        algorithm = name[0]
        parameters = name[1]
        text = ''
        for parameter in parameters:
            text += f"{parameter.upper()} : {self.input_dict[parameter]}\n"
        self.info_recon.setText(f"{text}\n Elapsed time for reconstruction: {1/fps:.3f}")